package com.cg.ibs.rm.ui;

public enum AutoPaymentUi {
	ADDAUTOPAYMENTS, REMOVEAUTOPAYMENTS, EXIT
}
