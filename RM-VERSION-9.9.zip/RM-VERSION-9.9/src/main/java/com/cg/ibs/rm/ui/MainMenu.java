package com.cg.ibs.rm.ui;

public enum MainMenu {
	 CUSTOMER, BANKREPRESENTATIVE, QUIT
}
