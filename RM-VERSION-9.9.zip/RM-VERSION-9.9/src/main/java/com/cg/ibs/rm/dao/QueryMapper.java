package com.cg.ibs.rm.dao;

public interface QueryMapper {
	

}
